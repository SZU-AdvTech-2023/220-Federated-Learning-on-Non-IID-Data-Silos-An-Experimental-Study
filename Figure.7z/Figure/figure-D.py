import re
import matplotlib.pyplot as plt

# 初始化四个数组
test_accuracy_fedprox = [0]
test_accuracy_scaffold = [0]
test_accuracy_fedavg = [0]
test_accuracy_fednova = [0]
communication_rounds_fedprox = []
communication_rounds_scaffold = []
communication_rounds_fedavg = []
communication_rounds_fednova = []

# 读取txt文件
with open('DBLIFedProx.txt', 'r') as file:
    lines = file.readlines()
    for line in lines:
        test_match = re.search(r'Global Model Train accuracy: ([\d.]+)', line)
        comm_round_match = re.search(r'in comm round:([\d.]+)', line)

        if test_match:
            test_accuracy_fedprox.append(float(test_match.group(1)))

        if comm_round_match:
            communication_rounds_fedprox.append(int(comm_round_match.group(1)))

with open('DBLISCAFFOLD.txt', 'r') as file:
    lines = file.readlines()
    for line in lines:
        test_match = re.search(r'Global Model Train accuracy: ([\d.]+)', line)
        comm_round_match = re.search(r'in comm round:([\d.]+)', line)

        if test_match:
            test_accuracy_scaffold.append(float(test_match.group(1)))

        if comm_round_match:
            communication_rounds_scaffold.append(int(comm_round_match.group(1)))

with open('DBLIFedAvg.txt', 'r') as file:
    lines = file.readlines()
    for line in lines:
        test_match = re.search(r'Global Model Train accuracy: ([\d.]+)', line)
        comm_round_match = re.search(r'in comm round:([\d.]+)', line)

        if test_match:
            test_accuracy_fedavg.append(float(test_match.group(1)))

        if comm_round_match:
            communication_rounds_fedavg.append(int(comm_round_match.group(1)))

with open('DBLIFedNova.txt', 'r') as file:
    lines = file.readlines()
    for line in lines:
        test_match = re.search(r'Global Model Train accuracy: ([\d.]+)', line)
        comm_round_match = re.search(r'in comm round:([\d.]+)', line)

        if test_match:
            test_accuracy_fednova.append(float(test_match.group(1)))

        if comm_round_match:
            communication_rounds_fednova.append(int(comm_round_match.group(1)))

# 绘制折线图
plt.figure(figsize=(8, 6))
plt.subplot(1, 1, 1)

plt.plot(communication_rounds_fedprox[:], test_accuracy_fedprox, label='FedProx')
plt.plot(communication_rounds_scaffold[:], test_accuracy_scaffold, label='SCAFFOLD')
plt.plot(communication_rounds_fedavg[:], test_accuracy_fedavg, label='FedAvg')
plt.plot(communication_rounds_fednova[:], test_accuracy_fednova, label='FedNova')

plt.xlabel('Communication round')
plt.ylabel('Test acc')
plt.legend()
#plt.xlim(0, 100)
plt.xticks([0, 10, 20, 30, 40, 50], fontproperties = 'Times New Roman', size = 20)
plt.yticks([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7], fontproperties = 'Times New Roman', size = 20)
plt.tight_layout()
plt.show()
